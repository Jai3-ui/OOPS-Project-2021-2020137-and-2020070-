package sample;

public class Cleaver extends Weapons{
    private String name="c";
    public Cleaver(int power, int level) {
        super(power, level);
    }
}
