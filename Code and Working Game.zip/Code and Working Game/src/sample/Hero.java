package sample;
import java.io.*;
import java.util.ArrayList;
import java.util.EventObject;

import javafx.event.ActionEvent;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.image.ImageView;
import javafx.stage.Stage;

public class Hero extends GameObjects implements Serializable{

    private static EventObject act;
    private Boolean isAlive;
    private Boolean RessurectedOnce;
    private Helmet helmet;
    private Weapons currentWeapon;
    private ArrayList<Weapons> WeaponList;
    private double xcoord;
    private double ycoord;
    private double Height;



    private int coin;



    private int highscore;


    private ImageView Image;


    private Integer power=5;
    public Hero(Helmet helmet, double xcoord, double ycoord, ImageView Image, double Height) {
  //      super();
        this.helmet = helmet;
        this.xcoord=xcoord;
        this.ycoord=ycoord;
        this.Image=Image;
        this.Height=Height;
        this.setAlive(true);
        this.setRessurectedOnce(false);
        GameObjects.setListOfObjects(this);

    }


    static void losegame(){
        System.out.println("lose");



    }

    public Helmet getHelmet() {
        return helmet;
    }
    public int getCoin() {
        return coin;
    }

    public void setCoin(int coin) {
        this.coin = coin;
    }

    public void setHelmet(Helmet helmet) {
        this.helmet = helmet;
    }


    //getter setter
    public  Boolean getAlive() {
        return isAlive;
    }

    public void setAlive(Boolean alive) {
        isAlive = alive;
    }

    public Boolean getRessurectedOnce() {
        return RessurectedOnce;
    }

    public void setRessurectedOnce(Boolean ressurectedOnce) {
        RessurectedOnce = ressurectedOnce;
    }
    public Weapons getCurrentWeapon() {
        return currentWeapon;
    }
    public int getHighscore() {
        return highscore;
    }

    public void setHighscore(int highscore) {
        this.highscore = highscore;
    }

    public void serialize() throws IOException {
        ObjectOutputStream out = null;
        try {
            out = new ObjectOutputStream(new FileOutputStream("save.txt"));
            out.writeObject(this);
        } catch (Exception e) {
            throw e;
        } finally {
            if (out != null) {
                out.close();
            }
        }
    }

    public static Hero deserialize() throws IOException, ClassNotFoundException {
        ObjectInputStream out = null;
        Hero game=null;
        try {
            out = new ObjectInputStream(new FileInputStream("save.txt"));
            game=(Hero) out.readObject();
            // out.writeObject(this);
        } catch (Exception e) {
            throw e;
        } finally {
            if (out != null) {

                out.close();
            }
        }
        return game;
    }

    public void setCurrentWeapon(Weapons currentWeapon) {
        this.currentWeapon = currentWeapon;
    }


//    public ArrayList<Weapons> getWeaponList() {
//        return WeaponList;
//    }
//
//
//    public void setWeaponList(ArrayList<Weapons> weaponList) {
//        WeaponList = weaponList;
//    }

    public double getHeight() {
        return Height;
    }
    @Override
    public double getYcoord() {
        return ycoord;
    }
    @Override

    public void setYcoord(double ycoord) {
        this.ycoord = ycoord;
    }
    @Override

    public double getXcoord() {
        return xcoord;
    }
    @Override

    public void setXcoord(double xcoord) {
        this.xcoord = xcoord;
    }


    public Integer getPower() {
        return power;
    }

    public void setPower(Integer power) {
        this.power = power;
    }


    public ImageView getImage() {
        return Image;
    }

    public void setImage(ImageView image) {
        Image = image;
    }




}
