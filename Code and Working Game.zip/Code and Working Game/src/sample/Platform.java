package sample;

import javafx.scene.image.ImageView;

import java.util.ArrayList;

public class Platform extends GameObjects{
    private double length;
    private double ycoord;
    private double xcoord;
    private Chest chest;
    private Coins coin;
    private Orcs orc;
    private ImageView Image;
    private static ArrayList<Platform> listofplatform=new ArrayList<Platform>();
    private static ArrayList<ImageView> listofplatformimages=new ArrayList<ImageView>();

    public Platform(double length,double ycoord,double startcoord,ImageView Image) {
        this.length=length;
        this.ycoord=ycoord;
        this.xcoord=startcoord;
        this.Image= Image;
        GameObjects.setListOfObjects(this);
        Image.setFitHeight(100);
        Image.setFitWidth(this.getLength());
        Image.setLayoutX(this.getXcoord());
        Image.setLayoutY(this.getYcoord());
        Image.setPreserveRatio(true);
        Image.setSmooth(true);
        Image.setCache(true);
        GameObjects.setListOfObjects(this);
        setListofplatform(this);
        setListofplatformimages(this.Image);
    }


    //getter setter


    public ImageView getImage() {
        return Image;
    }

    public void setImage(ImageView image) {
        Image = image;
    }

    @Override
    public double getYcoord() {
        return ycoord;
    }

    @Override
    public void setYcoord(double ycoord) {
        this.ycoord = ycoord;
    }
    public double getLength() {
        return length;
    }

    public void setLength(double length) {
        this.length = length;
    }

    @Override
    public double getXcoord() {
        return xcoord;
    }

    @Override
    public void setXcoord(double xcoord) {
        this.xcoord = xcoord;
    }

    public static ArrayList<Platform> getListofplatform() {
        return listofplatform;
    }


    public void setListofplatform(Platform o) {
        listofplatform.add(o);
    }

    public static ArrayList<ImageView> getListofplatformimages() {
        return listofplatformimages;
    }


    public void setListofplatformimages(ImageView o) {
        listofplatformimages.add(o);
    }




}
