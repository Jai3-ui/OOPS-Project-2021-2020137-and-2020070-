package sample;

import java.io.IOException;

public class Loadgame {
    public  void LoadGame1() throws IOException, ClassNotFoundException {
        Hero obj=Hero.deserialize();




    }


}
