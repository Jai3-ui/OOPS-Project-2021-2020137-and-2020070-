package sample;
import com.sun.scenario.effect.impl.sw.sse.SSEBlend_SRC_OUTPeer;
import javafx.animation.AnimationTimer;
import javafx.animation.TranslateTransition;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Group;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.*;
import javafx.scene.paint.Color;
import javafx.scene.shape.Line;
import javafx.scene.shape.Rectangle;
import javafx.scene.text.Font;
import javafx.scene.text.FontWeight;
import javafx.scene.text.Text;
import javafx.stage.Stage;
import javafx.util.Duration;
import org.w3c.dom.css.Rect;
import java.io.IOException;
import java.net.URL;
import java.util.ArrayList;
import java.util.EventObject;
import java.util.ResourceBundle;


public class Controller implements Initializable {
    TranslateTransition animation1 = new TranslateTransition();


    @FXML
    private AnchorPane mainpage;

    @FXML
    private Button GameMenu;

    @FXML
    private TextField Textfield;
    int coin = 0;


    public void InGame_Menu(ActionEvent act2) throws IOException {
        Parent root = FXMLLoader.load(getClass().getResource("page4.fxml"));
        Stage stage = (Stage) ((Node) act2.getSource()).getScene().getWindow();
        stage.setScene(new Scene(root));
        stage.show();
    }


    Group grp = new Group();
    Image hero = new Image("Game_Images/Hero.jpg");
    ImageView heroimg = new ImageView(hero);
    int count = 1;
    int score = 0;
    Group grp1 = new Group();
    ArrayList<Integer> arr1 = new ArrayList<>(123);
    Helmet helmet = new Helmet("Blue");
    Hero hemro = new Hero(helmet, 50, 300, heroimg, -50);

    public boolean IsCollide(ImageView heroimg, ImageView image2) {
        if (heroimg.getBoundsInParent().intersects(image2.getBoundsInParent())) {
            return true;
        }
        ;
        return false;
    }


    @Override
    public void initialize(URL url, ResourceBundle resourceBundle) {
        ani.start();
        mainpage.getChildren().add(grp1);
        mainpage.getChildren().add(grp);
        Label txt = new Label("Location of Hero -> " + count);
        txt.setLayoutX(250);
        txt.setLayoutY(20);
        txt.setFont(Font.font(25));
        grp1.getChildren().add(txt);

        Label txt1 = new Label("Score -> " + score);
        txt1.setLayoutX(250);
        txt1.setLayoutY(20 + 10 + 5 + 10 + 5 + 5);
        txt1.setFont(Font.font(25));
        grp1.getChildren().add(txt1);

        Textfield.setText("Coin -> " + coin);





        Button button = new Button("Click To Move Forward !");
        button.setLayoutX(250);
        button.setLayoutY(hemro.getYcoord() + 250);
        grp1.getChildren().add(button);
        button.setOnAction(new EventHandler<>() {
            @Override
            public void handle(ActionEvent actionEvent) {
                for (ImageView i : Platform.getListofplatformimages()) {
                    TranslateTransition tt = new TranslateTransition();
                    tt.setNode(i);
                    tt.setDuration(Duration.millis(250));
                    tt.setByX(-80);
                    tt.setRate(15);
                    tt.play();
                    tt.setOnFinished(event -> {
                        i.setLayoutX(i.getLayoutX() - 80);
                    });

                }

                for (ImageView i : Coins.getListofCoinImages()) {
                    TranslateTransition tt = new TranslateTransition();
                    tt.setNode(i);
                    tt.setDuration(Duration.millis(250));
                    tt.setByX(-80);
                    tt.setRate(15);
                    tt.play();
                    tt.setOnFinished(event -> {
                        i.setLayoutX(i.getLayoutX() - 80);
                    });

                }

                for (ImageView i : Chest.getListofchestimage()) {
                    TranslateTransition tt = new TranslateTransition();
                    tt.setNode(i);
                    tt.setDuration(Duration.millis(250));
                    tt.setByX(-80);
                    tt.setRate(15);
                    tt.play();
                    tt.setOnFinished(event -> {
                        i.setLayoutX(i.getLayoutX() - 80);
                    });

                }

                for (ImageView i : Orcs.getListoforcimage()) {
                    TranslateTransition tt = new TranslateTransition();
                    tt.setNode(i);
                    tt.setDuration(Duration.millis(250));
                    tt.setByX(-80);
                    tt.setRate(15);
                    tt.play();
                    tt.setOnFinished(event -> {
                        i.setLayoutX(i.getLayoutX() - 80);
                    });

                }

                for (ImageView i : TNT.getListooftntimages()) {
                    TranslateTransition tt = new TranslateTransition();
                    tt.setNode(i);
                    tt.setDuration(Duration.millis(250));
                    tt.setByX(-80);
                    tt.setRate(15);
                    tt.play();
                 //   System.out.println("sunishka");
                    tt.setOnFinished(event -> {
                        i.setLayoutX(i.getLayoutX() - 80);
                    });

                }


                count++;
                score++;
                txt.setText("Location -> " + count);
                txt1.setText("Score -> " + score);


            }
        });


        heroimg.setFitHeight(30);
        heroimg.setFitWidth(30);
        heroimg.setLayoutX(hemro.getXcoord());
        heroimg.setLayoutY(hemro.getYcoord());
        heroimg.setPreserveRatio(true);
        heroimg.setSmooth(true);
        heroimg.setCache(true);
        grp1.getChildren().add(heroimg);

//        Line fallLine = new Line(5.0f, 2.5f, 320.0f, 2.5f);
//        fallLine.setOpacity(1.0);
//        fallLine.setTranslateX(275);
//        fallLine.setTranslateY(248);
//        grp1.getChildren().add(fallLine);
//        Line rescrnline = new Line(5.0f, 2.5f, 320.0f, 2.5f);
//        rescrnline.setOpacity(1.0);
//        rescrnline.setTranslateX(275);
//        rescrnline.setTranslateY(482);
//        grp1.getChildren().add(rescrnline);

        heroimg.translateYProperty().addListener((obs, old, newValue) -> {
            double x = hemro.getXcoord();
            double y = hemro.getYcoord();
            for (int i = 0; i < Platform.getListofplatform().size(); i++) {
                ArrayList<Platform> temp = Platform.getListofplatform();


            }


        });

        animation1.setNode(heroimg);
        animation1.setAutoReverse(true);
        animation1.setDuration(Duration.millis(1500));
        animation1.setFromY(0);
        animation1.setToY(hemro.getHeight());
        animation1.setRate(2);
        animation1.setCycleCount(TranslateTransition.INDEFINITE);
        animation1.play();
        // grp1.getChildren().add(heroimg);


        //Placing islands
        //Placing islands
        //Placing islands
        Image Island = new Image("Game_Images/Islands1.png");
        ImageView islandimg = new ImageView(Island);
        Platform plat = new Platform(200, hemro.getYcoord() + 15, (50), islandimg);
        grp.getChildren().add(islandimg);

        Image Island1 = new Image("Game_Images/Islands1.png");
        ImageView islandimg1 = new ImageView(Island1);
        Platform plat1 = new Platform(200, hemro.getYcoord() + 15, (250), islandimg1);
        grp.getChildren().add(islandimg1);



        Image Island2 = new Image("Game_Images/Islands1.png");
        ImageView islandimg2 = new ImageView(Island2);
        Platform plat2 = new Platform(200, hemro.getYcoord() + 15, 500 + 15 + 10, islandimg2);
        grp.getChildren().add(islandimg2);

        Image Island3 = new Image("Game_Images/Islands1.png");
        ImageView islandimg3 = new ImageView(Island3);
        Platform plat3 = new Platform(200, hemro.getYcoord() + 15, 750 + 15 + 10, islandimg3);
        grp.getChildren().add(islandimg3);


        Image Island4 = new Image("Game_Images/Islands1.png");
        ImageView islandimg4 = new ImageView(Island4);
        Platform plat4 = new Platform(200, hemro.getYcoord() + 15, 1000 + 20 + 10, islandimg4);
        grp.getChildren().add(islandimg4);

        Image Island5 = new Image("Game_Images/Islands1.png");
        ImageView islandimg5 = new ImageView(Island5);
        Platform plat5 = new Platform(200, hemro.getYcoord() + 15, 1250 + 20 + 10, islandimg5);
        grp.getChildren().add(islandimg5);

        Image Island6 = new Image("Game_Images/Islands1.png");
        ImageView islandimg6 = new ImageView(Island6);
        Platform plat6 = new Platform(200, hemro.getYcoord() + 15, 1500 + 20 + 10, islandimg6);
        grp.getChildren().add(islandimg6);

        Image Island7 = new Image("Game_Images/Islands1.png");
        ImageView islandimg7 = new ImageView(Island7);
        Platform plat7 = new Platform(200, hemro.getYcoord() + 15, 1750 + 20 + 10, islandimg7);
        grp.getChildren().add(islandimg7);

        Image Island8 = new Image("Game_Images/Islands1.png");
        ImageView islandimg8 = new ImageView(Island8);
        Platform plat8 = new Platform(200, hemro.getYcoord() + 15, 2000 + 20 + 10, islandimg8);
        grp.getChildren().add(islandimg8);

        Image Island9 = new Image("Game_Images/Islands1.png");
        ImageView islandimg9 = new ImageView(Island9);
        Platform plat9 = new Platform(200, hemro.getYcoord() + 15, 2250 + 20 + 10, islandimg9);
        grp.getChildren().add(islandimg9);

        Image Island10 = new Image("Game_Images/Islands1.png");
        ImageView islandimg10 = new ImageView(Island10);
        Platform plat10 = new Platform(200, hemro.getYcoord() + 15, 2500 + 20 + 10, islandimg10);
        grp.getChildren().add(islandimg10);

        Image Island11 = new Image("Game_Images/Islands1.png");
        ImageView islandimg11 = new ImageView(Island11);
        Platform plat11 = new Platform(200, hemro.getYcoord() + 15, 2750 + 20 + 10, islandimg11);
        grp.getChildren().add(islandimg11);

        Image Island12 = new Image("Game_Images/Islands1.png");
        ImageView islandimg12 = new ImageView(Island12);
        Platform plat12 = new Platform(200, hemro.getYcoord() + 15, 3000 + 20 + 10, islandimg12);
        grp.getChildren().add(islandimg12);

        Image Island13 = new Image("Game_Images/Islands1.png");
        ImageView islandimg13 = new ImageView(Island13);
        Platform plat13 = new Platform(200, hemro.getYcoord() + 15, 3250 + 20 + 10, islandimg13);
        grp.getChildren().add(islandimg13);

        Image Island14 = new Image("Game_Images/Islands1.png");
        ImageView islandimg14 = new ImageView(Island14);
        Platform plat14 = new Platform(200, hemro.getYcoord() + 15, 3500 + 20 + 10, islandimg14);
        grp.getChildren().add(islandimg14);

        Image Island15 = new Image("Game_Images/Islands1.png");
        ImageView islandimg15 = new ImageView(Island15);
        Platform plat15 = new Platform(200, hemro.getYcoord() + 15, 3750 + 20 + 10, islandimg15);
        grp.getChildren().add(islandimg15);

        Image Island16 = new Image("Game_Images/Islands1.png");
        ImageView islandimg16 = new ImageView(Island16);
        Platform plat16 = new Platform(200, hemro.getYcoord() + 15, 4000 + 20 + 10, islandimg16);
        grp.getChildren().add(islandimg16);

        Image Island17 = new Image("Game_Images/Islands1.png");
        ImageView islandimg17 = new ImageView(Island17);
        Platform plat17 = new Platform(200, hemro.getYcoord() + 15, 4250 + 20 + 10, islandimg17);
        grp.getChildren().add(islandimg17);

        Image Island18 = new Image("Game_Images/Islands1.png");
        ImageView islandimg18 = new ImageView(Island18);
        Platform plat18 = new Platform(200, hemro.getYcoord() + 15, 4500 + 20 + 10, islandimg18);
        grp.getChildren().add(islandimg18);

        Image Island19 = new Image("Game_Images/Islands1.png");
        ImageView islandimg19 = new ImageView(Island19);
        Platform plat19 = new Platform(200, hemro.getYcoord() + 15, 4750 + 20 + 10, islandimg19);
        grp.getChildren().add(islandimg19);

        Image Island20 = new Image("Game_Images/Islands1.png");
        ImageView islandimg20 = new ImageView(Island20);
        Platform plat20 = new Platform(200, hemro.getYcoord() + 15, 5000 + 20 + 10, islandimg20);
        grp.getChildren().add(islandimg20);

        Image Island21 = new Image("Game_Images/Islands1.png");
        ImageView islandimg21 = new ImageView(Island21);
        Platform plat21 = new Platform(200, hemro.getYcoord() + 15, 5250 + 20 + 10, islandimg21);
        grp.getChildren().add(islandimg21);

        Image Island22 = new Image("Game_Images/Islands1.png");
        ImageView islandimg22 = new ImageView(Island22);
        Platform plat22 = new Platform(200, hemro.getYcoord() + 15, 5500 + 20 + 10, islandimg22);
        grp.getChildren().add(islandimg22);

        Image Island23 = new Image("Game_Images/Islands1.png");
        ImageView islandimg23 = new ImageView(Island23);
        Platform plat23 = new Platform(200, hemro.getYcoord() + 15, 5750 + 20 + 10, islandimg23);
        grp.getChildren().add(islandimg23);

        Image Island24 = new Image("Game_Images/Islands1.png");
        ImageView islandimg24 = new ImageView(Island24);
        Platform plat24 = new Platform(200, hemro.getYcoord() + 15, 6000 + 20 + 10, islandimg24);
        grp.getChildren().add(islandimg24);

        Image Island25 = new Image("Game_Images/Islands1.png");
        ImageView islandimg25 = new ImageView(Island25);
        Platform plat25 = new Platform(200, hemro.getYcoord() + 15, 6250 + 20 + 10, islandimg25);
        grp.getChildren().add(islandimg25);

        Image Island26 = new Image("Game_Images/Islands1.png");
        ImageView islandimg26 = new ImageView(Island26);
        Platform plat26 = new Platform(200, hemro.getYcoord() + 15, 6500 + 20 + 10, islandimg26);
        grp.getChildren().add(islandimg26);

        Image Island27 = new Image("Game_Images/Islands1.png");
        ImageView islandimg27 = new ImageView(Island27);
        Platform plat27 = new Platform(200, hemro.getYcoord() + 15, 6750 + 20 + 10, islandimg27);
        grp.getChildren().add(islandimg27);

        Image Island28 = new Image("Game_Images/Islands1.png");
        ImageView islandimg28 = new ImageView(Island28);
        Platform plat28 = new Platform(200, hemro.getYcoord() + 15, 7000 + 20 + 10, islandimg28);
        grp.getChildren().add(islandimg28);

        Image Island29 = new Image("Game_Images/Islands1.png");
        ImageView islandimg29 = new ImageView(Island29);
        Platform plat29 = new Platform(200, hemro.getYcoord() + 15, 7250 + 20 + 10, islandimg29);
        grp.getChildren().add(islandimg29);

        Image Island30 = new Image("Game_Images/Islands1.png");
        ImageView islandimg30 = new ImageView(Island30);
        Platform plat30 = new Platform(200, hemro.getYcoord() + 15, 7500 + 20 + 10, islandimg30);
        grp.getChildren().add(islandimg30);

        Image Island31 = new Image("Game_Images/Islands1.png");
        ImageView islandimg31 = new ImageView(Island31);
        Platform plat31 = new Platform(200, hemro.getYcoord() + 15, 7750 + 20 + 10, islandimg31);
        grp.getChildren().add(islandimg31);

        Image Island32 = new Image("Game_Images/Islands1.png");
        ImageView islandimg32 = new ImageView(Island32);
        Platform plat32 = new Platform(200, hemro.getYcoord() + 15, 8000 + 20 + 10, islandimg32);
        grp.getChildren().add(islandimg32);

        Image Island33 = new Image("Game_Images/Islands1.png");
        ImageView islandimg33 = new ImageView(Island33);
        Platform plat33 = new Platform(200, hemro.getYcoord() + 15, 8250 + 20 + 10, islandimg33);
        grp.getChildren().add(islandimg33);

        Image Island34 = new Image("Game_Images/Islands1.png");
        ImageView islandimg34 = new ImageView(Island34);
        Platform plat34 = new Platform(200, hemro.getYcoord() + 15, 8500 + 20 + 10, islandimg34);
        grp.getChildren().add(islandimg34);

        Image Island35 = new Image("Game_Images/Islands1.png");
        ImageView islandimg35 = new ImageView(Island35);
        Platform plat35 = new Platform(200, hemro.getYcoord() + 15, 8750 + 20 + 10, islandimg35);
        grp.getChildren().add(islandimg35);

        Image Island36 = new Image("Game_Images/Islands1.png");
        ImageView islandimg36 = new ImageView(Island36);
        Platform plat36 = new Platform(200, hemro.getYcoord() + 15, 9000 + 20 + 10, islandimg36);
        grp.getChildren().add(islandimg36);

        Image Island37 = new Image("Game_Images/Islands1.png");
        ImageView islandimg37 = new ImageView(Island37);
        Platform plat37 = new Platform(200, hemro.getYcoord() + 15, 9250 + 20 + 10, islandimg37);
        grp.getChildren().add(islandimg37);

        Image Island38 = new Image("Game_Images/Islands1.png");
        ImageView islandimg38 = new ImageView(Island28);
        Platform plat38 = new Platform(200, hemro.getYcoord() + 15, 9500 + 20 + 10, islandimg38);
        grp.getChildren().add(islandimg38);

        Image Island39 = new Image("Game_Images/Islands1.png");
        ImageView islandimg39 = new ImageView(Island29);
        Platform plat39 = new Platform(200, hemro.getYcoord() + 15, 9750 + 20 + 10, islandimg39);
        grp.getChildren().add(islandimg39);

        Image Island40 = new Image("Game_Images/Islands1.png");
        ImageView islandimg40 = new ImageView(Island30);
        Platform plat40 = new Platform(200, hemro.getYcoord() + 15, 10000 + 20 + 10, islandimg40);
        grp.getChildren().add(islandimg40);

        Image Island41 = new Image("Game_Images/Islands1.png");
        ImageView islandimg41 = new ImageView(Island41);
        Platform plat41 = new Platform(200, hemro.getYcoord() + 15, 10250 + 20 + 10, islandimg41);
        grp.getChildren().add(islandimg41);

        Image Island42 = new Image("Game_Images/Islands1.png");
        ImageView islandimg42 = new ImageView(Island42);
        Platform plat42 = new Platform(200, hemro.getYcoord() + 15, 10500 + 20 + 10, islandimg42);
        grp.getChildren().add(islandimg42);

        Image Island43 = new Image("Game_Images/Islands1.png");
        ImageView islandimg43 = new ImageView(Island43);
        Platform plat43 = new Platform(200, hemro.getYcoord() + 15, 10750+30, islandimg43);
        grp.getChildren().add(islandimg43);

        Image Island44 = new Image("Game_Images/Islands1.png");
        ImageView islandimg44 = new ImageView(Island44);
        Platform plat44 = new Platform(200, hemro.getYcoord() + 15, 11000 + 20 + 10, islandimg44);
        grp.getChildren().add(islandimg44);

        Image Island45 = new Image("Game_Images/Islands1.png");
        ImageView islandimg45 = new ImageView(Island15);
        Platform plat45 = new Platform(200, hemro.getYcoord() + 15, 11250 + 20 + 10, islandimg45);
        grp.getChildren().add(islandimg45);

        Image Island46 = new Image("Game_Images/Islands1.png");
        ImageView islandimg46 = new ImageView(Island16);
        Platform plat46 = new Platform(200, hemro.getYcoord() + 15, 11600 + 20 + 10, islandimg46);
        grp.getChildren().add(islandimg46);

        Image Island47 = new Image("Game_Images/Islands1.png");
        ImageView islandimg47 = new ImageView(Island47);
        Platform plat47 = new Platform(200, hemro.getYcoord() + 15, 11900 + 20 + 10, islandimg47);
        grp.getChildren().add(islandimg47);

        Image Island48 = new Image("Game_Images/Islands1.png");
        ImageView islandimg48 = new ImageView(Island48);
        Platform plat48 = new Platform(200, hemro.getYcoord() + 15, 12250 + 20 + 10, islandimg48);
        grp.getChildren().add(islandimg48);

        Image Island49 = new Image("Game_Images/Islands1.png");
        ImageView islandimg49 = new ImageView(Island49);
        Platform plat49 = new Platform(200, hemro.getYcoord() + 15, 12550 + 20 + 10, islandimg49);
        grp.getChildren().add(islandimg49);

        Image Island50 = new Image("Game_Images/Islands1.png");
        ImageView islandimg50 = new ImageView(Island50);
        Platform plat50 = new Platform(200, hemro.getYcoord() + 15, 12750 + 20 + 10, islandimg50);
        grp.getChildren().add(islandimg50);


        Image Island51 = new Image("Game_Images/Islands1.png");
        ImageView islandimg51 = new ImageView(Island51);
        Platform plat51 = new Platform(200, hemro.getYcoord() + 15, 13000 + 20 + 10, islandimg51);
        grp.getChildren().add(islandimg51);

        Image Island52 = new Image("Game_Images/Islands1.png");
        ImageView islandimg52 = new ImageView(Island52);
        Platform plat52 = new Platform(200, hemro.getYcoord() + 15, 13300 + 20 + 10, islandimg52);
        grp.getChildren().add(islandimg52);

        Image Island53 = new Image("Game_Images/Islands1.png");
        ImageView islandimg53 = new ImageView(Island53);
        Platform plat53 = new Platform(200, hemro.getYcoord() + 15, 13600 + 20 + 10 , islandimg53);
        grp.getChildren().add(islandimg53);


        Image Island54 = new Image("Game_Images/Islands1.png");
        ImageView islandimg54 = new ImageView(Island54);
        Platform plat54 = new Platform(200, hemro.getYcoord() + 15, 13900 + 20 + 10 , islandimg54);
        grp.getChildren().add(islandimg54);


        Image Island55 = new Image("Game_Images/Islands1.png");
        ImageView islandimg55 = new ImageView(Island55);
        Platform plat55 = new Platform(200, hemro.getYcoord() + 15, 14200 + 20 + 10 , islandimg55);
        grp.getChildren().add(islandimg55);

        Image Island56 = new Image("Game_Images/Islands1.png");
        ImageView islandimg56 = new ImageView(Island56);
        Platform plat56 = new Platform(200, hemro.getYcoord() + 15, 14450 + 20 + 10 , islandimg56);
        grp.getChildren().add(islandimg56);

        Image Island57 = new Image("Game_Images/Islands1.png");
        ImageView islandimg57 = new ImageView(Island57);
        Platform plat57 = new Platform(200, hemro.getYcoord() + 15, 14750 + 20 + 10 , islandimg57);
        grp.getChildren().add(islandimg57);

        Image Island58 = new Image("Game_Images/Islands1.png");
        ImageView islandimg58 = new ImageView(Island53);
        Platform plat58 = new Platform(200, hemro.getYcoord() + 15, 15000 + 20 + 10 , islandimg58);
        grp.getChildren().add(islandimg58);


        Image Island59 = new Image("Game_Images/Islands1.png");
        ImageView islandimg59 = new ImageView(Island59);
        Platform plat59 = new Platform(200, hemro.getYcoord() + 11, 15250 + 20 + 10 , islandimg59);
        grp.getChildren().add(islandimg59);


        Image Island60 = new Image("Game_Images/Islands1.png");
        ImageView islandimg60 = new ImageView(Island60);
        Platform plat60 = new Platform(200, hemro.getYcoord() + 15, 15500 + 20 + 10 , islandimg60);
        grp.getChildren().add(islandimg60);

        Image Island61 = new Image("Game_Images/Islands1.png");
        ImageView islandimg61 = new ImageView(Island61);
        Platform plat61 = new Platform(200, hemro.getYcoord() + 15, 15750 + 20 + 10 , islandimg61);
        grp.getChildren().add(islandimg61);

        Image Island62 = new Image("Game_Images/Islands1.png");
        ImageView islandimg62 = new ImageView(Island62);
        Platform plat62 = new Platform(200, hemro.getYcoord() + 15, 15900 + 20 + 10, islandimg62);
        grp.getChildren().add(islandimg62);

        Image Island63 = new Image("Game_Images/Islands1.png");
        ImageView islandimg63 = new ImageView(Island63);
        Platform plat63 = new Platform(200, hemro.getYcoord() + 15, 16200 + 20 + 10 , islandimg63);
        grp.getChildren().add(islandimg63);

        Image Island64 = new Image("Game_Images/Islands1.png");
        ImageView islandimg64 = new ImageView(Island64);
        Platform plat64 = new Platform(200, hemro.getYcoord() + 15, 16400 , islandimg64);
        grp.getChildren().add(islandimg64);

//placing tnt
        Image Tnt=new Image("Game_Images/TNT.png");
        ImageView tnt1=new ImageView(Tnt);
        TNT tnt2=new TNT(50,hemro.getYcoord()-15,plat10.getXcoord()+50+50+200,tnt1);
        grp.getChildren().add(tnt1);

        Image tnt=new Image("Game_Images/TNT.png");
        ImageView tnt11=new ImageView(tnt);
        TNT tnt12=new TNT(50,plat1.getYcoord()-27,plat20.getXcoord()+50+200+150,tnt11);
        grp.getChildren().add(tnt11);

        Image tnt13=new Image("Game_Images/TNT.png");
        ImageView tnt14=new ImageView(tnt13);
        TNT tnt15=new TNT(50,plat1.getYcoord()-27,plat20.getXcoord()+50+200+150,tnt14);
        grp.getChildren().add(tnt14);

        Image tnt16=new Image("Game_Images/TNT.png");
        ImageView tnt17=new ImageView(tnt13);
        TNT tnt18=new TNT(50,plat1.getYcoord()-27,plat30.getXcoord()+50+200+150,tnt17);
        grp.getChildren().add(tnt17);



//placing orcs
        Image orci1 = new Image("Game_Images/Orc2.png");
        ImageView orcii1 = new ImageView(orci1);
        Orcs orc1 = new GreenOrc(4, 0, 5, hemro.getHeight(), plat5.getXcoord() + 40, plat5.getYcoord() - 30, plat5, orcii1);
        grp.getChildren().add(orcii1);


        Image orci2 = new Image("Game_Images/RedOrc1.png");
        ImageView orcii2 = new ImageView(orci2);
        Orcs orc2 = new RedOrc(4, 0, 5, hemro.getHeight(), plat8.getXcoord() + 60, plat8.getYcoord() - 30, plat8, orcii2);
        grp.getChildren().add(orcii2);

        Image orci3 = new Image("Game_Images/Orc2.png");
        ImageView orcii3 = new ImageView(orci3);
        Orcs orc3 = new Orcs(4, 0, 5, hemro.getHeight(), plat10.getXcoord() + 20, plat10.getYcoord() - 30, plat10, orcii3);
        grp.getChildren().add(orcii3);

        Image orci4 = new Image("Game_Images/Orc2.png");
        ImageView orcii4 = new ImageView(orci4);
        Orcs orc4 = new Orcs(4, 0, 5, hemro.getHeight(), plat12.getXcoord() + 100, plat12.getYcoord() - 30, plat5, orcii4);
        grp.getChildren().add(orcii4);

        Image orci5 = new Image("Game_Images/RedOrc1.png");
        ImageView orcii5 = new ImageView(orci5);
        Orcs orc5 = new RedOrc(4, 0, 5, hemro.getHeight(), plat18.getXcoord() + 40, plat5.getYcoord() - 30, plat5, orcii5);
        grp.getChildren().add(orcii5);


        Image orci6 = new Image("Game_Images/Orc2.png");
        ImageView orcii6 = new ImageView(orci6);
        Orcs orc6 = new Orcs(5, 0, 5, hemro.getHeight(), plat22.getXcoord() + 20, plat8.getYcoord() - 30, plat8, orcii6);
        grp.getChildren().add(orcii6);

        Image orci7 = new Image("Game_Images/RedOrc1.png");
        ImageView orcii7 = new ImageView(orci7);
        Orcs orc7 = new RedOrc(5, 0, 5, hemro.getHeight(), plat28.getXcoord() + 80, plat10.getYcoord() - 30, plat10, orcii7);
        grp.getChildren().add(orcii7);

        Image orci8 = new Image("Game_Images/Orc2.png");
        ImageView orcii8 = new ImageView(orci8);
        Orcs orc8 = new Orcs(10, 0, 5, hemro.getHeight(), plat32.getXcoord() + 120, plat12.getYcoord() - 30, plat5, orcii8);
        grp.getChildren().add(orcii8);

        Image orci9 = new Image("Game_Images/Orc2.png");
        ImageView orcii9 = new ImageView(orci9);
        Orcs orc9 = new Orcs(6, 0, 5, hemro.getHeight(), plat36.getXcoord() + 40, plat5.getYcoord() - 30, plat5, orcii9);
        grp.getChildren().add(orcii9);


        Image orci10 = new Image("Game_Images/RedOrc1.png");
        ImageView orcii10 = new ImageView(orci10);
        Orcs orc10 = new RedOrc(6, 0, 5, hemro.getHeight(), plat40.getXcoord() - 20, plat8.getYcoord() - 30, plat8, orcii10);
        grp.getChildren().add(orcii10);

        Image orci11 = new Image("Game_Images/Orc2.png");
        ImageView orcii11 = new ImageView(orci11);
        Orcs orc11 = new Orcs(6, 0, 5, hemro.getHeight(), plat44.getXcoord() + 120, plat10.getYcoord() - 30, plat10, orcii11);
        grp.getChildren().add(orcii11);

        Image orci12 = new Image("Game_Images/Orc2.png");
        ImageView orcii12 = new ImageView(orci12);
        Orcs orc12 = new Orcs(10, 0, 5, hemro.getHeight(), plat48.getXcoord() + 120, plat10.getYcoord() - 30, plat10, orcii12);
        grp.getChildren().add(orcii12);

        Image orci13 = new Image("Game_Images/RedOrc1.png");
        ImageView orcii13 = new ImageView(orci13);
        Orcs orc13 = new RedOrc(10, 0, 5, hemro.getHeight(), plat50.getXcoord() + 50, plat10.getYcoord() - 30, plat10, orcii13);
        grp.getChildren().add(orcii13);

        Image orci14 = new Image("Game_Images/Orc5.png");
        ImageView orcii14 = new ImageView(orci14);
        BossOrc orc14 = new BossOrc(10, 0, 5, hemro.getHeight()+50, plat64.getXcoord() + 50, plat60.getYcoord() - 30, plat60, orcii14);
        grp.getChildren().add(orcii14);


//adding weapon chests
        Image wc1 = new Image("Game_Images/Chest.jpg");
        ImageView wci1 = new ImageView(wc1);
        WeaponChest weapnchst1 = new WeaponChest(wci1, plat3.getXcoord() + 60, plat3.getYcoord() - 20);
        grp.getChildren().add(wci1);

        Image wc2 = new Image("Game_Images/Chest.jpg");
        ImageView wci2 = new ImageView(wc2);
        WeaponChest weapnchs2 = new WeaponChest(wci2, plat15.getXcoord() + 60, plat3.getYcoord() - 20);
        grp.getChildren().add(wci2);

        Image wc3 = new Image("Game_Images/Chest.jpg");
        ImageView wci3 = new ImageView(wc3);
        WeaponChest weapnchst3 = new WeaponChest(wci3, plat33.getXcoord() + 60, plat3.getYcoord() - 20);
        grp.getChildren().add(wci3);


        //adding coin chests
        Image cc1 = new Image("Game_Images/Chest.jpg");
        ImageView cci1 = new ImageView(cc1);
        WeaponChest cchst1 = new WeaponChest(cci1, plat7.getXcoord() + 60, plat3.getYcoord() - 20);
        grp.getChildren().add(cci1);

        Image cc2 = new Image("Game_Images/ChestClosed.png");
        ImageView cci2 = new ImageView(cc2);
        WeaponChest cchst2 = new WeaponChest(cci2, plat25.getXcoord() + 60, plat3.getYcoord() - 20);
        grp.getChildren().add(cci2);

        Image cc3 = new Image("Game_Images/ChestClosed.png");
        ImageView cci3 = new ImageView(cc3);
        WeaponChest cchst3 = new WeaponChest(cci3, plat43.getXcoord() + 60, plat3.getYcoord() - 20);
        grp.getChildren().add(cci3);


        //adding coins
        Image coin1 = new Image("Game_Images/Coin.png");
        ImageView coini1 = new ImageView(coin1);
        Coins coins1 = new Coins(coini1, 20, plat4.getXcoord() + 60, plat3.getYcoord() - 12);
        grp.getChildren().add(coini1);

        Image coin2 = new Image("Game_Images/Coin.png");
        ImageView coini2 = new ImageView(coin2);
        Coins coins2 = new Coins(coini2, 20, plat4.getXcoord() + 80, plat3.getYcoord() - 12);
        grp.getChildren().add(coini2);

        Image coin3 = new Image("Game_Images/Coin.png");
        ImageView coini3 = new ImageView(coin3);
        Coins coins3 = new Coins(coini3, 20, plat4.getXcoord() + 100, plat3.getYcoord() - 12);
        grp.getChildren().add(coini3);

        Image coin4 = new Image("Game_Images/Coin.png");
        ImageView coini4 = new ImageView(coin4);
        Coins coins4 = new Coins(coini4, 20, plat9.getXcoord() + 60, plat3.getYcoord() - 12);
        grp.getChildren().add(coini4);

        Image coin5 = new Image("Game_Images/Coin.png");
        ImageView coini5 = new ImageView(coin5);
        Coins coins5 = new Coins(coini5, 20, plat9.getXcoord() + 80, plat3.getYcoord() - 12);
        grp.getChildren().add(coini5);

        Image coin6 = new Image("Game_Images/Coin.png");
        ImageView coini6 = new ImageView(coin6);
        Coins coins6 = new Coins(coini6, 20, plat16.getXcoord() + 60, plat3.getYcoord() - 12);
        grp.getChildren().add(coini6);

        Image coin7 = new Image("Game_Images/Coin.png");
        ImageView coini7 = new ImageView(coin7);
        Coins coins7 = new Coins(coini7, 20, plat16.getXcoord() + 80, plat3.getYcoord() - 12);
        grp.getChildren().add(coini7);

        Image coin8 = new Image("Game_Images/Coin.png");
        ImageView coini8 = new ImageView(coin8);
        Coins coins8 = new Coins(coini8, 20, plat16.getXcoord() + 120, plat3.getYcoord() - 12);
        grp.getChildren().add(coini8);

        Image coin9 = new Image("Game_Images/Coin.png");
        ImageView coini9 = new ImageView(coin9);
        Coins coins9 = new Coins(coini9, 20, plat17.getXcoord() + 80, plat3.getYcoord() - 12);
        grp.getChildren().add(coini9);


        Image coin10 = new Image("Game_Images/Coin.png");
        ImageView coini10 = new ImageView(coin10);
        Coins coins10 = new Coins(coini10, 20, plat17.getXcoord() + 100, plat3.getYcoord() - 12);
        grp.getChildren().add(coini10);

        Image coin11 = new Image("Game_Images/Coin.png");
        ImageView coini11 = new ImageView(coin11);
        Coins coins11 = new Coins(coini11, 20, plat21.getXcoord() + 60, plat3.getYcoord() - 12);
        grp.getChildren().add(coini11);

        Image coin12 = new Image("Game_Images/Coin.png");
        ImageView coini12 = new ImageView(coin12);
        Coins coins12 = new Coins(coini12, 20, plat21.getXcoord() + 80, plat3.getYcoord() - 12);
        grp.getChildren().add(coini12);

        Image coin13 = new Image("Game_Images/Coin.png");
        ImageView coini13 = new ImageView(coin13);
        Coins coins13 = new Coins(coini13, 20, plat23.getXcoord() + 60, plat3.getYcoord() - 12);
        grp.getChildren().add(coini13);

        Image coin14 = new Image("Game_Images/Coin.png");
        ImageView coini14 = new ImageView(coin14);
        Coins coins14 = new Coins(coini14, 20, plat25.getXcoord() + 100, plat3.getYcoord() - 12);
        grp.getChildren().add(coini14);

        Image coin15 = new Image("Game_Images/Coin.png");
        ImageView coini15 = new ImageView(coin15);
        Coins coins15 = new Coins(coini15, 20, plat27.getXcoord() + 60, plat3.getYcoord() - 12);
        grp.getChildren().add(coini15);

        Image coin16 = new Image("Game_Images/Coin.png");
        ImageView coini16 = new ImageView(coin16);
        Coins coins16 = new Coins(coini16, 20, plat27.getXcoord() + 80, plat3.getYcoord() - 12);
        grp.getChildren().add(coini16);

        Image coin17 = new Image("Game_Images/Coin.png");
        ImageView coini17 = new ImageView(coin17);
        Coins coins17 = new Coins(coini17, 20, plat27.getXcoord() + 100, plat3.getYcoord() - 12);
        grp.getChildren().add(coini17);

        Image coin18 = new Image("Game_Images/Coin.png");
        ImageView coini18 = new ImageView(coin18);
        Coins coins18 = new Coins(coini18, 20, plat30.getXcoord() + 60, plat3.getYcoord() - 12);
        grp.getChildren().add(coini18);

        Image coin19 = new Image("Game_Images/Coin.png");
        ImageView coini19 = new ImageView(coin19);
        Coins coins19 = new Coins(coini19, 20, plat30.getXcoord() + 80, plat3.getYcoord() - 12);
        grp.getChildren().add(coini19);

        Image coin20 = new Image("Game_Images/Coin.png");
        ImageView coini20 = new ImageView(coin20);
        Coins coins20 = new Coins(coini20, 20, plat33.getXcoord() + 20, plat3.getYcoord() - 12);
        grp.getChildren().add(coini20);

        Image coin21 = new Image("Game_Images/Coin.png");
        ImageView coini21 = new ImageView(coin21);
        Coins coins21 = new Coins(coini21, 20, plat33.getXcoord() + 100, plat3.getYcoord() - 12);
        grp.getChildren().add(coini21);

        Image coin22 = new Image("Game_Images/Coin.png");
        ImageView coini22 = new ImageView(coin22);
        Coins coins22 = new Coins(coini22, 20, plat36.getXcoord() + 80, plat3.getYcoord() - 12);
        grp.getChildren().add(coini22);

        Image coin23 = new Image("Game_Images/Coin.png");
        ImageView coini23 = new ImageView(coin23);
        Coins coins23 = new Coins(coini23, 20, plat38.getXcoord() + 80, plat3.getYcoord() - 12);
        grp.getChildren().add(coini23);

        Image coin24 = new Image("Game_Images/Coin.png");
        ImageView coini24 = new ImageView(coin24);
        Coins coins24 = new Coins(coini24, 20, plat38.getXcoord() + 100, plat3.getYcoord() - 12);
        grp.getChildren().add(coini24);

        Image coin25 = new Image("Game_Images/Coin.png");
        ImageView coini25 = new ImageView(coin25);
        Coins coins25 = new Coins(coini25, 20, plat38.getXcoord() + 120, plat3.getYcoord() - 12);
        grp.getChildren().add(coini25);

        Image coin26 = new Image("Game_Images/Coin.png");
        ImageView coini26 = new ImageView(coin26);
        Coins coins26 = new Coins(coini26, 20, plat42.getXcoord() + 80, plat3.getYcoord() - 12);
        grp.getChildren().add(coini26);

        Image coin27 = new Image("Game_Images/Coin.png");
        ImageView coini27 = new ImageView(coin27);
        Coins coins27 = new Coins(coini27, 20, plat42.getXcoord() + 120, plat3.getYcoord() - 12);
        grp.getChildren().add(coini27);

        Image coin28 = new Image("Game_Images/Coin.png");
        ImageView coini28 = new ImageView(coin28);
        Coins coins28 = new Coins(coini28, 20, plat44.getXcoord() + 80, plat3.getYcoord() - 12);
        grp.getChildren().add(coini28);

        Image coin29 = new Image("Game_Images/Coin.png");
        ImageView coini29 = new ImageView(coin29);
        Coins coins29 = new Coins(coini29, 20, plat44.getXcoord() + 50, plat3.getYcoord() - 12);
        grp.getChildren().add(coini29);

        Image coin30 = new Image("Game_Images/Coin.png");
        ImageView coini30 = new ImageView(coin30);
        Coins coins30 = new Coins(coini30, 20, plat45.getXcoord() + 100, plat3.getYcoord() - 12);
        grp.getChildren().add(coini30);

        Image coin31 = new Image("Game_Images/Coin.png");
        ImageView coini31 = new ImageView(coin31);
        Coins coins31 = new Coins(coini31, 20, plat45.getXcoord() + 120, plat3.getYcoord() - 12);
        grp.getChildren().add(coini31);

        Image coin32 = new Image("Game_Images/Coin.png");
        ImageView coini32 = new ImageView(coin32);
        Coins coins32 = new Coins(coini32, 20, plat45.getXcoord() + 140, plat3.getYcoord() - 12);
        grp.getChildren().add(coini32);

        Image coin33 = new Image("Game_Images/Coin.png");
        ImageView coini33 = new ImageView(coin33);
        Coins coins33 = new Coins(coini33, 20, plat46.getXcoord() + 100, plat3.getYcoord() - 12);
        grp.getChildren().add(coini33);

        Image coin34 = new Image("Game_Images/Coin.png");
        ImageView coini34 = new ImageView(coin34);
        Coins coins34 = new Coins(coini34, 20, plat46.getXcoord() + 150, plat3.getYcoord() - 12);
        grp.getChildren().add(coini34);

        Image coin35 = new Image("Game_Images/Coin.png");
        ImageView coini35 = new ImageView(coin35);
        Coins coins35 = new Coins(coini35, 20, plat48.getXcoord() + 50, plat3.getYcoord() - 12);
        grp.getChildren().add(coini35);

        Image coin36 = new Image("Game_Images/Coin.png");
        ImageView coini36 = new ImageView(coin36);
        Coins coins36 = new Coins(coini36, 20, plat48.getXcoord() + 80, plat3.getYcoord() - 12);
        grp.getChildren().add(coini36);

        Image coin37 = new Image("Game_Images/Coin.png");
        ImageView coini37 = new ImageView(coin37);
        Coins coins37 = new Coins(coini37, 20, plat48.getXcoord() + 110, plat3.getYcoord() - 12);
        grp.getChildren().add(coini37);

        Image coin38 = new Image("Game_Images/Coin.png");
        ImageView coini38 = new ImageView(coin38);
        Coins coins38 = new Coins(coini38, 20, plat50.getXcoord() + 80, plat3.getYcoord() - 12);
        grp.getChildren().add(coini38);

        Image coin39 = new Image("Game_Images/Coin.png");
        ImageView coini39 = new ImageView(coin39);
        Coins coins39 = new Coins(coini39, 20, plat50.getXcoord() + 100, plat3.getYcoord() - 12);
        grp.getChildren().add(coini39);


        Image coin40 = new Image("Game_Images/Coin.png");
        ImageView coini40 = new ImageView(coin40);
        Coins coins40 = new Coins(coini40, 20, plat51.getXcoord() + 80, plat3.getYcoord() - 12);
        grp.getChildren().add(coini40);

        Image coin41 = new Image("Game_Images/Coin.png");
        ImageView coini41 = new ImageView(coin41);
        Coins coins41 = new Coins(coini41, 20, plat51.getXcoord() + 180, plat3.getYcoord() - 12);
        grp.getChildren().add(coini41);





    }

    AnimationTimer ani = new AnimationTimer() {
        private EventObject act;
        @Override
        public void handle(long l) {


            for (int i = 0; i < Coins.getListofcoins().size(); i++) {
                if (IsCollide(heroimg, Coins.getListofcoins().get(i).getImage())) {
                    coin++;
                    Textfield.setText("Coins -> " + coin);
                    Coins.getListofcoins().get(i).getImage().imageProperty().setValue(null);
                    Coins.setremListofcoins(Coins.getListofcoins().get(i));
                    User.setCoins(coin);
                    hemro.setCoin(coin);
                    hemro.setHighscore(10);
                    System.out.println(User.getCoins());
                }
            }

            for (int i = 0; i < Orcs.getListoforcs().size(); i++) {
                if (IsCollide(heroimg, Orcs.getListoforcs().get(i).getImage())) {
                    System.out.println("Orcs Collide !!!");
                    if (hemro.getPower()>=Orcs.getPower()){
                        Orcs.getListoforcs().get(i).getImage().imageProperty().setValue(null);
                        Orcs.setremListoforcs(Orcs.getListoforcs().get(i));

                        }
                    else{
                        hemro.losegame();
                        try {
                            FXMLLoader fxmlLoader = new FXMLLoader(getClass().getResource("page5.fxml"));
                            Parent root1 = fxmlLoader.load();
                            Stage stage = new Stage();
                            stage.setScene(new Scene(root1,900,490));
                            stage.show();
                            //sc.close();
                            stage.close();

                        } catch(Exception e) {
                            e.printStackTrace();
                        }


                    }

                }
            }

            for (int i = 0; i < WeaponChest.getListofWeaponChest().size(); i++) {
                if (IsCollide(heroimg, WeaponChest.getListofWeaponChest().get(i).getImage())) {
                    System.out.println("WeaponChest  Collide !!!");
                    heroimg.setOpacity(0.00);
                    WeaponChest.getListofChest().get(i).getImage().imageProperty().setValue(null);
                    heroimg.imageProperty().setValue(null);
                    ImageView img = WeaponChest.SpawnWeapon(hemro);
                    img.setFitHeight(30);
                    img.setFitWidth(30);
                    img.setLayoutX(hemro.getXcoord());
                    img.setLayoutY(hemro.getYcoord());
                    img.setPreserveRatio(true);
                    img.setSmooth(true);
                    img.setCache(true);
                    hemro.setImage(img);
                    TranslateTransition animation2 = new TranslateTransition();
                    animation2.setNode(img);
                    animation2.setAutoReverse(true);
                    animation2.setDuration(Duration.millis(1500));
                    animation2.setFromY(0);
                    animation2.setToY(hemro.getHeight());
                    animation2.setRate(2);
                    animation2.setCycleCount(TranslateTransition.INDEFINITE);
                    animation2.play();
                    grp1.getChildren().add(img);
                    WeaponChest.setremListofWeaponChest(WeaponChest.getListofWeaponChest().get(i));

                }
            }

            for(int i=0;i<TNT.getListooftnt().size();i++){
                if(IsCollide(heroimg,TNT.getListooftnt().get(i).getImage())){
                    try {
                        FXMLLoader fxmlLoader = new FXMLLoader(getClass().getResource("page5.fxml"));
                        Parent root1 = fxmlLoader.load();
                        Stage stage = new Stage();
                        stage.setScene(new Scene(root1,1400,1000));
                        stage.show();
                      //  s.close();
                    } catch(Exception e) {
                        e.printStackTrace();
                    }


                }
            }

            for(int i=0;i<CoinChest.getListofCoinChests().size();i++){
                if(IsCollide(heroimg,CoinChest.getListofCoinChests().get(i).getImage())){
                    coin+=10;
                    Textfield.setText("Coin -> "+coin);
                    User.setCoins(coin);
                    hemro.setCoin(coin);
                }
            }


            for (int i = 0; i < Platform.getListofplatform().size(); i++) {
                if((heroimg.getBoundsInParent().getMaxY()>(hemro.getYcoord()+15)) && (IsCollide(heroimg,Platform.getListofplatform().get(i).getImage())==false)){
                    System.out.println("fall");
                }


            }





        }
    };



}











