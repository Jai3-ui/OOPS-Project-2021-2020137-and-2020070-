package sample;
import javafx.scene.image.ImageView;
public class RedOrc extends Orcs{
    public RedOrc(int power, int level, int RewardCoins, double Height, double xcoord, double ycoord, Platform currentPlatform, ImageView Image) {
        super(power, level, RewardCoins, Height, xcoord, ycoord, currentPlatform, Image);
    }
}
