package sample;

import javafx.scene.image.ImageView;

import java.util.ArrayList;

public class CoinChest extends Chest{
    private Coins coin;
    private double xcoord;
    private double ycoord;
    private ImageView Image;



    private static ArrayList<CoinChest> listofCoinChests = new ArrayList <CoinChest>();
    public CoinChest(ImageView image, double xcoord, double ycoord) {
        super(image,xcoord,ycoord);
        this.Image=image;
        this.xcoord=xcoord;
        this.ycoord=ycoord;
        GameObjects.setListOfObjects(this);
        Image.setFitHeight(30);
        Image.setFitWidth(30);
        Image.setLayoutX(this.getXcoord());
        Image.setLayoutY(this.getYcoord());
        Image.setPreserveRatio(true);
        Image.setSmooth(true);
        Image.setCache(true);
        setListofCoinChests(this);

    }
    public static ArrayList<CoinChest> getListofCoinChests() {
        return listofCoinChests;
    }

    public static void setListofCoinChests(CoinChest c) {
        listofCoinChests.add(c);
    }
    public static void remsetListofCoinChests(CoinChest c) {
        listofCoinChests.remove(c);
    }
}
