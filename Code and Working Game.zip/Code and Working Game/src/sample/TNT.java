package sample;
import javafx.scene.image.ImageView;
import java.util.ArrayList;
public class TNT extends GameObjects {

    private double length;
    private double ycoord;
    private double startcoord;
    private ImageView Image;
    private static ArrayList<TNT> listooftnt= new ArrayList<TNT>();
    private static ArrayList<ImageView> listooftntimages= new ArrayList<ImageView>();

    public TNT(double length, double ycoord, double startcoord,  ImageView Img) {
        this.length=length;
        this.ycoord=ycoord;
        this.startcoord=startcoord;
        this.Image=Img;
        Img.setFitHeight(30);
        Img.setFitWidth(this.getLength());
        Img.setLayoutX(this.getStartcoord());
        Img.setLayoutY(this.getYcoord());
        Img.setPreserveRatio(true);
        Img.setSmooth(true);
        Img.setCache(true);
        setListooftnt(this);
        setListooftntimages(Img);
        GameObjects.setListOfObjects(this);
    }


    //getter setter
    public static void setListooftntimages(ImageView i) {
        listooftntimages.add(i);
    }



    @Override
    public double getYcoord() {
        return ycoord;
    }

    public ImageView getImage() {
        return Image;
    }

    public void setImage(ImageView image) {
        Image = image;
    }

    @Override
    public void setYcoord(double ycoord) {
        this.ycoord = ycoord;
    }
    public double getLength() {
        return length;
    }

    public void setLength(double length) {
        this.length = length;
    }

    public double getStartcoord() {
        return startcoord;
    }

    public void setStartcoord(double startcoord) {
        this.startcoord = startcoord;
    }

    public static ArrayList<TNT> getListooftnt() {
        return listooftnt;
    }

    public static void setListooftnt(TNT t) {
        listooftnt.add(t);
    }
    public static ArrayList<ImageView> getListooftntimages() {
        return listooftntimages;
    }



}
