package sample;

public class User {
    private String name;
    private int Score;
    private static int Coins;
    private double Progress;
    private Hero Player;

    private void ResurrectPlayer(){
        if (!this.Player.getAlive()&& !this.Player.getRessurectedOnce()){
            this.Player.setAlive(true);
            this.Player.setRessurectedOnce(true);

        }
        else{

        }

    }



    //getter setter
    public static int getCoins() {
        return Coins;
    }

    public static void setCoins(int coins) {
        Coins = coins;
    }
    public int getScore() {
        return Score;
    }

    public double getProgress() {
        return Progress;
    }

    public void setProgress(double progress) {
        Progress = progress;
    }


    public void setScore(int score) {
        Score = score;
    }
    public void setName(String name) {
        this.name = name;
    }

    public String getName() {
        return name;
    }
}
