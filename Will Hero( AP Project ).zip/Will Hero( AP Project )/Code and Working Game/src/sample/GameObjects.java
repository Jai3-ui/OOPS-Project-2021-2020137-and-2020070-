package sample;
import javafx.scene.image.ImageView;

import java.io.*;
import java.util.ArrayList;
public class GameObjects implements Serializable {
    private Game currentGame;
    private static ArrayList<GameObjects> listOfObjects=new ArrayList<GameObjects>();
    private double xcoord;
    private double ycoord;
    private ImageView Image;

    public GameObjects() {
        this.currentGame = currentGame;
        this.xcoord=xcoord;
        this.ycoord=ycoord;
        this.Image=Image;
     //   listOfObjects.add(this);
    }

    //getter and setter
    public double getYcoord() {
        return ycoord;
    }

    public void setYcoord(double ycoord) {
        this.ycoord = ycoord;
    }

    public double getXcoord() {
        return xcoord;
    }

    public void setXcoord(double xcoord) {
        this.xcoord = xcoord;
    }

    public static ArrayList<GameObjects> getListOfObjects() {
        return listOfObjects;
    }

    public static void setListOfObjects(GameObjects listOfObjects) {
         GameObjects.listOfObjects.add(listOfObjects);
    }









    }



