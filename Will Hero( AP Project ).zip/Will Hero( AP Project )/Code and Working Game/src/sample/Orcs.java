package sample;


import javafx.animation.TranslateTransition;
import javafx.scene.image.ImageView;
import javafx.util.Duration;

import java.util.ArrayList;
public class Orcs extends GameObjects{



    private static int power;
    private int level;
    private int RewardCoins;
    private double Height;
    private double xcoord;
    private double ycoord;
    private Platform currentPlatform;
    private static ArrayList<ImageView> listoforcimage=new ArrayList<ImageView>();



    private ImageView Image;
    private static ArrayList<Orcs> listoforcs = new ArrayList <Orcs>();

    public Orcs(int power,int level,int RewardCoins,double Height,double xcoord,double ycoord, Platform currentPlatform,ImageView Image) {
        this.power = power;
        this.level = level;
        this.RewardCoins = RewardCoins;
        this.Height = Height;
        this.currentPlatform = currentPlatform;
        this.xcoord=xcoord;
        this.ycoord=ycoord;
        this.Image=Image;
        GameObjects.setListOfObjects(this);
        Image.setFitHeight(30);
        Image.setFitWidth(30);
        Image.setLayoutX(this.getXcoord());
        Image.setLayoutY(this.getYcoord());
        Image.setPreserveRatio(true);
        Image.setSmooth(true);
        Image.setCache(true);
        TranslateTransition animation2=new TranslateTransition();
        animation2.setNode(Image);
        animation2.setAutoReverse(true);
        animation2.setDuration(Duration.millis(1500));
        animation2.setFromY(0);
        animation2.setToY(-50);
        animation2.setRate(2);
        animation2.setCycleCount(TranslateTransition.INDEFINITE);
        animation2.play();
        setListoforcs(this);
        setListoforcimage(this.Image);


    }


    //gettersetter
    @Override
    public double getYcoord() {
        return ycoord;
    }
    @Override

    public void setYcoord(double ycoord) {
        this.ycoord = ycoord;
    }
    @Override

    public double getXcoord() {
        return xcoord;
    }
    @Override

    public void setXcoord(double xcoord) {
        this.xcoord = xcoord;
    }

    public double getHeight() {
        return Height;
    }
    public Platform getCurrentPlatform() {
        return currentPlatform;
    }

    public void setCurrentPlatform(Platform currentPlatform) {
        this.currentPlatform = currentPlatform;
    }
    public static int getPower() {
        return power;
    }

    public void setPower(int power) {
        this.power = power;
    }

    public int getLevel() {
        return level;
    }

    public int getRewardCoins() {
        return RewardCoins;
    }

    public static ArrayList<Orcs> getListoforcs() {
        return listoforcs;
    }

    public static void setListoforcs(Orcs o) {
        listoforcs.add(o);
    }
    public ImageView getImage() {
        return Image;
    }

    public void setImage(ImageView image) {
        Image = image;
    }

    public static ArrayList<ImageView> getListoforcimage() {
        return listoforcimage;
    }

    public void setListoforcimage(ImageView i) {
        listoforcimage.add(i);
    }

    public static void setremListoforcs(Orcs c) {
        listoforcs.remove(c);
    }

}
