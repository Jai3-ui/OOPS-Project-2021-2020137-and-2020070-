package sample;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;

import java.util.ArrayList;

public class WeaponChest extends Chest{
    private Weapons weapons;
    private double xcoord;
    private double ycoord;
    private ImageView Image;
    private static ArrayList<WeaponChest> listofWeaponChest = new ArrayList <WeaponChest>();

    public WeaponChest(ImageView image, double xcoord, double ycoord) {
        super(image,xcoord,ycoord);
        this.Image=image;
        this.xcoord=xcoord;
        this.ycoord=ycoord;
        GameObjects.setListOfObjects(this);
        Image.setFitHeight(30);
        Image.setFitWidth(30);
        Image.setLayoutX(this.getXcoord());
        Image.setLayoutY(this.getYcoord());
        Image.setPreserveRatio(true);
        Image.setSmooth(true);
        Image.setCache(true);
        setListofWeaponChest(this);
    }
    
    static ImageView SpawnWeapon(Hero h){
        int a= (int) (1+(Math.random()*2));
        if (a==1){
            Image img=new Image("Game_Images/herowithweapon.jpg");
            ImageView img1=new ImageView(img);

            if(h.getCurrentWeapon()!=null&& h.getCurrentWeapon().getName()=="c"){
                Cleaver cleaver=new Cleaver(10,2);
                h.setCurrentWeapon(cleaver);
                h.setPower(15);
                return img1;

            }
            else {

                Cleaver cleaver=new Cleaver(5,1);
                h.setCurrentWeapon(cleaver);
                h.setPower(10);
                return img1;

            }

        }
        Image img=new Image("Game_Images/download.jpg");
        ImageView img1=new ImageView(img);

        if(h.getCurrentWeapon()!=null&& h.getCurrentWeapon().getName()=="h"){
            Hammer hammer =new Hammer(10,2);
            h.setCurrentWeapon(hammer);
            h.setPower(15);
            return img1;

        }
        else {
            Hammer hammer =new Hammer(5,1);
            h.setCurrentWeapon(hammer);
            h.setPower(10);
            return img1;
        }



    }


    public static ArrayList<WeaponChest> getListofWeaponChest() {
        return listofWeaponChest;
    }

    public static void setListofWeaponChest(WeaponChest w) {
       listofWeaponChest.add(w);
    }
    public static void setremListofWeaponChest(WeaponChest w) {
        listofWeaponChest.remove(w);
    }
    @Override
    public ImageView getImage() {
        return Image;
    }
    
    

    @Override
    public void setImage(ImageView image) {
        Image = image;
        Image.setFitHeight(30);
        Image.setFitWidth(30);
        Image.setLayoutX(this.getXcoord());
        Image.setLayoutY(this.getYcoord());
        Image.setPreserveRatio(true);
        Image.setSmooth(true);
        Image.setCache(true);
    }
}
