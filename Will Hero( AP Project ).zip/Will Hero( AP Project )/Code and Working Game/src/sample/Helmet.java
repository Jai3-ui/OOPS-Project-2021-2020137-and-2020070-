package sample;

public class Helmet  {
    private String name;

    public Helmet(String name) {
        this.name = name;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

}
