package sample;

import javafx.animation.TranslateTransition;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Group;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.ButtonType;
import javafx.scene.layout.AnchorPane;
import javafx.stage.Stage;
import javafx.util.Duration;

import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;

public class Controller2 implements Initializable {
    @FXML
    private AnchorPane page1;
    @FXML
    private Button StartGame;

    @FXML
    private  Button Loading;

    @FXML
    private Button ExitGame;

    @FXML
    private  Button submission;

    public  void Exit(ActionEvent event){
        Alert alert;
        alert=new Alert(Alert.AlertType.CONFIRMATION);
        alert.setTitle(" Exit ");
        alert.setHeaderText(" You are about to Exit the Game !!!");
        alert.setContentText(" Do You want to Exit from the Game ? ");
        if(alert.showAndWait().get()== ButtonType.OK){
            Stage stage;
            stage=(Stage) page1.getScene().getWindow();
            System.out.printf("You Exit From the Game");
            stage.close();
        }
    }

    public  void Start_Game(ActionEvent act) throws IOException {
        //  LabelText.setText(" You Started the Game ");
        StartGame.setStyle("fx-background-color: #33ccff");
        Parent root = FXMLLoader.load(getClass().getResource("page2.fxml"));
        Stage stage=(Stage) ((Node) act.getSource()).getScene().getWindow();
        stage.setScene(new Scene(root));
        stage.show();

    }

    @FXML
    private Button SaveGame;

    @FXML
    private Button Continue;

    @FXML
    private  Button Restart;

    @FXML
    private Button ExitMain;


    public void MainMenu(ActionEvent act3) throws  IOException{
        Alert alert;
        alert=new Alert(Alert.AlertType.CONFIRMATION);
        alert.setTitle(" Exit to Main Menu  ");
        alert.setHeaderText(" You are about to Exit to  the Main Menu !!!");
        alert.setContentText(" Do You want to Exit to the Main Menu ? ");
        if(alert.showAndWait().get()== ButtonType.OK){
            Parent root = FXMLLoader.load(getClass().getResource("page1.fxml"));
            Stage stage=(Stage) ((Node) act3.getSource()).getScene().getWindow();
            stage.setScene(new Scene(root));
            stage.show();
        }
    }


    public void Continuing(ActionEvent act1) throws IOException{
        Alert alert;
        alert=new Alert(Alert.AlertType.CONFIRMATION);
        alert.setTitle(" Restart !!! ");
        alert.setHeaderText(" You are about to Restart  the Game !!!");
        alert.setContentText(" Do You want to Restart the  Game ? ");
        if(alert.showAndWait().get()== ButtonType.OK){
            Parent root = FXMLLoader.load(getClass().getResource("sample.fxml"));
            Stage stage=(Stage) ((Node) act1.getSource()).getScene().getWindow();
            stage.setScene(new Scene(root));
            stage.show();
        }
    }



    public void Submit_Name(ActionEvent act1) throws IOException{
     //   Highlight.setText(" Hii "+Naming.getText()+" You can Now Play the Game!!!");
        Parent root = FXMLLoader.load(getClass().getResource("sample.fxml"));
        Stage stage=(Stage) ((Node) act1.getSource()).getScene().getWindow();
        //  stage.setScene(new Scene(root));
        Scene sc=new Scene(root);
        stage.setScene(sc);
        stage.show();
    }








    @Override
    public void initialize(URL url, ResourceBundle resourceBundle) {

    }
}

