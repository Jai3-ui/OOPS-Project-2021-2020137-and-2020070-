package sample;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.stage.Stage;

import java.io.IOException;

//import java.awt.*;

public class Controller3 {
    @FXML
    private Button bahar;

    @FXML
    private  Button pagemove;

    public void Submit_Name(ActionEvent act1) throws IOException {
        //   Highlight.setText(" Hii "+Naming.getText()+" You can Now Play the Game!!!");
        Parent root = FXMLLoader.load(getClass().getResource("page1.fxml"));
        Stage stage=(Stage) ((Node) act1.getSource()).getScene().getWindow();
        //  stage.setScene(new Scene(root));
        Scene sc=new Scene(root);
        stage.setScene(sc);
        stage.show();
    }

    public void Submit_Name1(ActionEvent act1) throws IOException{
        //   Highlight.setText(" Hii "+Naming.getText()+" You can Now Play the Game!!!");
        Parent root = FXMLLoader.load(getClass().getResource("sample.fxml"));
        Stage stage=(Stage) ((Node) act1.getSource()).getScene().getWindow();
        //  stage.setScene(new Scene(root));
        Scene sc=new Scene(root);
        stage.setScene(sc);
        stage.show();
    }
}
