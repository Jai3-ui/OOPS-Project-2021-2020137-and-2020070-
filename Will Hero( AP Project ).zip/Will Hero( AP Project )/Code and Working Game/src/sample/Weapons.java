package sample;
import java.util.ArrayList;

import static sample.GameObjects.getListOfObjects;

public class Weapons extends GameObjects {
    private String name= null;

    private int power;
    private int level;
    public Weapons(int power, int level) {
        this.power = power;
        this.level=level;
        GameObjects.setListOfObjects(this);

    }

    //gettersetter
    public  String getName(){return name;}
    public int getLevel() {
        return level;
    }

    public void setLevel(int level) {
        this.level = level;
    }
    public int getPower() {
        return power;
    }

    public void setPower(int power) {
        this.power = power;
    }



}
