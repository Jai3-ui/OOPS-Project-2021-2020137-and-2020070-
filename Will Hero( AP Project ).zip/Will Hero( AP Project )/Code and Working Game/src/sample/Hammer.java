package sample;

public class Hammer extends Weapons{
    private String name="h";
    public Hammer(int power, int level) {
        super(power, level);
    }
}
