package sample;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import java.util.ArrayList;
public class Chest extends GameObjects {
    private double xcoord;
    private double ycoord;
    private ImageView image;
    private static ArrayList<Chest> listofChest = new ArrayList <Chest>();
    private static  ArrayList<ImageView> listofchestimage=new ArrayList<ImageView>();


    public Chest(ImageView image,double xcoord,double ycoord) {
        this.image=image;
        this.xcoord=xcoord;
        this.ycoord=ycoord;
        image.setFitHeight(30);
        image.setFitWidth(30);
        image.setLayoutX(this.getXcoord());
        image.setLayoutY(this.getYcoord());
        image.setPreserveRatio(true);
        image.setSmooth(true);
        image.setCache(true);
        GameObjects.setListOfObjects(this);
        setListofChest(this);
        setListofchestimage(this.image);


    }


    private void open(){

    }
    protected void spawnWeapon(){

    }
    protected void spawnCoin(){

    }






    //gettersetter
    @Override
    public double getXcoord() {
        return xcoord;
    }

    @Override
    public void setXcoord(double xcoord) {
        this.xcoord = xcoord;
    }
    @Override
    public double getYcoord() {
        return ycoord;
    }

    @Override
    public void setYcoord(double ycoord) {
        this.ycoord = ycoord;
    }

    public static ArrayList<Chest> getListofChest() {
        return listofChest;
    }

    public static void setListofChest(Chest o) {
       listofChest.add(o);
    }

    public ImageView getImage() {
        return image;
    }

    public void setImage(ImageView image) {
        this.image = image;
    }

    public static ArrayList<ImageView> getListofchestimage() {
        return listofchestimage;
    }

    public static void setListofchestimage(ImageView i) {
        listofchestimage.add(i);
    }

    public static void setremListofchest(Chest c) {
        listofChest.remove(c);
    }

}
