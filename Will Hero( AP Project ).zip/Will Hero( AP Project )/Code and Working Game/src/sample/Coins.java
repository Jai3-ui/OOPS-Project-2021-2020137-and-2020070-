package sample;
import javafx.scene.image.ImageView;
import java.util.ArrayList;



public class Coins extends GameObjects{
    private double xcoord;
    private double ycoord;
    private Integer value;
    private ImageView Image;
    private static ArrayList<Coins> listofcoins = new ArrayList <Coins>();
    private static ArrayList<ImageView> listofCoinImages=new ArrayList<ImageView>();

    public Coins(ImageView image,Integer value,double xcoord, double ycoord) {
        this.Image=image;
        this.value=value;
        this.xcoord=xcoord;
        this.ycoord=ycoord;
        GameObjects.setListOfObjects(this);
        Image.setFitHeight(15);
        Image.setFitWidth(15);
        Image.setLayoutX(this.getXcoord());
        Image.setLayoutY(this.getYcoord());
        Image.setPreserveRatio(true);
        Image.setSmooth(true);
        Image.setCache(true);
        GameObjects.setListOfObjects(this);
        setListofcoins(this);
        setListofCoinImages(this.Image);



    }
    //gettersetter
    @Override
    public double getXcoord() {
        return xcoord;
    }

    @Override
    public void setXcoord(double xcoord) {
        this.xcoord = xcoord;
    }
    @Override
    public double getYcoord() {
        return ycoord;
    }

    @Override
    public void setYcoord(double ycoord) {
        this.ycoord = ycoord;
    }

    public Integer getValue() {
        return value;
    }

    public void setValue(Integer value) {
        this.value = value;
    }

    public static ArrayList<Coins> getListofcoins() {
        return listofcoins;
    }

    public static void setListofcoins(Coins c) {
        listofcoins.add(c);
    }
    public static void setremListofcoins(Coins c) {
        listofcoins.remove(c);
    }

    public ImageView getImage() {
        return Image;
    }

    public void setImage(ImageView image) {
        Image = image;
    }


    public static ArrayList<ImageView> getListofCoinImages() {
        return listofCoinImages;
    }

    public static void setListofCoinImages(ImageView I) {
        listofCoinImages.add(I);
    }


}
