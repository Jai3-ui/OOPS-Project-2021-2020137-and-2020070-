package sample;

public class Game {
    private User CurrentPlayer;
    private GameObjects ourobjects;

    private static int Highscore=0;

    public static int getHighscore() {
        return Highscore;
    }

    public void setHighscore(int highscore) {
        if (this.getCurrentPlayer().getScore()>Highscore)
            Highscore = highscore;
    }
    public User getCurrentPlayer() {
        return CurrentPlayer;
    }

    //constructor
    public Game(GameObjects g) {
        this.ourobjects =g;
    }

    private void LoadGame(){

    }
    private void PauseGame(){

    }
    private void ResumeGame(){

    }
    private void ExitGame(){

    }
    private void SaveGame(){

    }
    private void SpendCoin(int n){
        User.setCoins(User.getCoins()-n);

    }
    private void WinGame(){

    }
    private void LoseGame(){

    }

}
